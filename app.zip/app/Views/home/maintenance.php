<!-- app/Views/maintenance.php -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Maintenance</title>
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 100px;
        }
        h1 {
            font-size: 36px;
            color: #333;
        }
        p {
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Situs Sedang Dalam Pemeliharaan</h1>
    <p>Kami sedang melakukan pemeliharaan sistem. Silakan kembali lagi nanti.</p>
</body>
</html>
